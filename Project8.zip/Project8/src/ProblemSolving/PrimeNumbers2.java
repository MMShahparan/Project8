package ProblemSolving;

public class PrimeNumbers2 {
    public static void main(String[] args) {
        for (int 1=2; i<100; i++) {
            if (i==2){
                System.out.println(i);
            } else {
                if (isPrime(i)){
                    System.out.println(i);
                }
            }
        }


    }
}
