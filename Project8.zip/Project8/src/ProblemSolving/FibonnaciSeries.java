package ProblemSolving;

public class FibonnaciSeries {

    public static void main(String[] args) {
            }


}
